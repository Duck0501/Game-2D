using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Player_Controller : MonoBehaviour
{
    [SerializeField] private float speed/*, atkSpeed, countDown = 0*/ ;
    [SerializeField] private GameObject bullet;
    [SerializeField] Transform firePoint;
    private Rigidbody2D rb;
    private Animator anim;
    private string currentAnim;
    public Slider Slider;
    public float maxHeath;
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
        Slider.maxValue = maxHeath;
        Slider.value = maxHeath;
    }

    // Update is called once per frame
    void Update()
    {
        Move();
        Attack();
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.CompareTag("box"))
        {
            SceneManager.LoadScene("Level 2");
        }
        else if (other.gameObject.CompareTag("box2"))
        {
            SceneManager.LoadScene("Level 3");
        }
    }

    private void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.CompareTag("enemy"))
        {
            changrAnim("hurt");
            Slider.value--;
            if(Slider.value == Slider.minValue)
            {
                SceneManager.LoadScene("Game over");
            }
        }

    }
    void Move()
    {
        float horizontal = Input.GetAxisRaw("Horizontal");
        float vertical = Input.GetAxisRaw("Vertical");
        Vector2 movement = new Vector2(horizontal, vertical).normalized;
        

        if(MathF.Abs(horizontal) > 0.1f )
        {
            changrAnim("run");
            transform.rotation = Quaternion.Euler(new Vector3(0, (horizontal > 0.1f)? 0: -180,0));
            rb.velocity = movement * speed * Time.deltaTime;
        }
        else if ( Mathf.Abs(vertical) > 0.1f)
        {
            changrAnim("run");
            rb.velocity = movement * speed * Time.deltaTime;
        }
        else
        {
            changrAnim("idle");
            rb.velocity = Vector2.zero;
        }
    }

    void Attack()
    {
        //countDown -= Time.deltaTime;
        //if (countDown > 0)
        //    return;

        if (Input.GetKeyDown(KeyCode.F))
        {
            changrAnim("combo");

            Instantiate(bullet, firePoint.position, transform.rotation);
            //countDown = atkSpeed;
        }
    }


    private void changrAnim(String AnimName)
    {
        if(currentAnim != AnimName)
        {
            anim.ResetTrigger(AnimName);
            currentAnim = AnimName;
            anim.SetTrigger(currentAnim);
        }
    }

}
